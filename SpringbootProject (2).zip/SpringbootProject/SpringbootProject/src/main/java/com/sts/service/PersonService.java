package com.sts.service;

import com.sts.PersonRepository;
import com.sts.exeption.PersonNotFoundExeption;
import com.sts.model.Person;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class PersonService implements PersonRepository {

    public static List<Person> persons = new ArrayList<>();

    // for stocking data in memory database before use
    static {
    persons.add(new Person(generateValue(), 29,"Amina"));
    persons.add(new Person(generateValue(), 25, "Abdourahmane"));
    persons.add(new Person(generateValue(), 30,"Ousseynou"));
    persons.add(new Person(generateValue(), 35,"Bira"));

    }
    private static  int generateValue() {
        id = id++;
        return id;
    }


    public static int id = 0;


    @Override
    public List<Person> findAll() {
        return persons;
    }

    @Override
    public Person findById(int id) {
        Person personToFind = new Person();

        for (Person personToGet :persons){
            if (personToGet.getId()==id){
                personToFind= personToGet;
            }
        }
        return personToFind;
    }

    @Override
    public Person save(Person person) {
        Person personCreated = new Person();
        personCreated.setId(generateValue());
        personCreated.setAge(person.getAge());
        personCreated.setName(person.getName());
        persons.add(personCreated);

        return personCreated;
    }

    @Override
    public Person update(Person person) {
        Person personUpdated = persons.stream().filter(p ->p.getId() ==person.getId()).findAny().orElseThrow(()->new PersonNotFoundExeption("this id is not available "));

        personUpdated.setAge(person.getAge());
        personUpdated.setName(person.getName());
        return personUpdated;
    }

    @Override
    public void delete(int id) {
        persons.removeIf(person -> person.getId() ==id);


    }
}
