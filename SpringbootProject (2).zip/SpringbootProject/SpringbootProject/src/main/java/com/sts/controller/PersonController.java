package com.sts.controller;

import com.sts.model.Person;
import com.sts.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/Person")


public class PersonController {
    @Autowired // field injection
    private  PersonService service;


   // public PersonController(PersonService service) {
        //this.service = service;

  //  }

 @GetMapping("/findAll")
    public List<Person> persons (){
     return service.findAll();
 }

 @GetMapping ("/findById")
 public Person findById(int id) {
     Person productToFind = new Person();
     for (Person personToGet :persons()){
         if (personToGet.getId()==id){
             personToFind =personToGet;
         }


         }
     return personToFind;






}
