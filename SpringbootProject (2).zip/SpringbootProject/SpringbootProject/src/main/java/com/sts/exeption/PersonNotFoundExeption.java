package com.sts.exeption;

public class PersonNotFoundExeption extends RuntimeException{

    public PersonNotFoundExeption(String message){
        super(message);
    }
}
